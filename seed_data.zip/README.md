Convex seed snapshot for preview deployments.
Import with:

npx convex import --preview-name "$VERCEL_GIT_COMMIT_REF" seed_data.zip

Contains a small synthetic dataset for:
- practices
- ruleSets
- practitioners
- locations
- appointmentTypes
- baseSchedules
